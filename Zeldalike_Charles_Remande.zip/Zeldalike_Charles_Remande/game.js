/* CONFIG ***************************************************************************************/
var config = {
	type: Phaser.AUTO,
	width: 800,
	height: 600,
    physics: {
        default: 'arcade',
        arcade: {
            gravity: 0,
            debug: true
            
        }
    },
    scene: {
        preload: preload,
        create: create,
        update: update
    }
};

var game = new Phaser.Game(config);	

var bloc;
var dalle;
var dalle_2;
var portes;
var piliers;
var rochers;
var murs;
var arbre;
var cactus;
var lac;
var player;
var cursors; 
var ammo;
var ammotext;
var livestext;
var itemshuri;
var itemvie;
var itemcle;
var lig;
var fleches3;
var fleches4;
var shuris;
var lastFired = 0;
var playerSpeed = 350;
var shuriSpeed = 900;
var scorpio;
var scorpio2;
var snake;
var snake2;
var time= 0;
var nbshuri = 10;
var UP = "UP";
var DOWN = "DOWN";
var LEFT = "LEFT";
var RIGHT = "RIGHT";
var direction = null;

// Projectile Constructor_____TO DO_____projectiles touchent pas les objets
var Shuriken = new Phaser.Class({

    Extends: Phaser.GameObjects.Image,

    initialize:

    function Shuriken (scene)
    {
        Phaser.GameObjects.Image.call(this, scene, 0, 0, 'shuri');
        this.born = 0;
        this.xSpeed = 0;
        this.ySpeed = 0;
        this.speed = shuriSpeed;
    },
	
	// Tirer projectile depuis joueur vers position
    fire: function (player)
    {
        this.setPosition(player.x, player.y); // Initial position

        switch(player.heading) {
            case UP :
                this.xSpeed = 0;
                this.ySpeed = -this.speed;
                break;
            case DOWN :
                this.xSpeed = 0;
                this.ySpeed = this.speed;
                break;
            case LEFT :
                this.xSpeed = -this.speed;
                this.ySpeed = 0;
                break;
            case RIGHT :
                this.xSpeed = this.speed;
                this.ySpeed = 0;
                break;
            default :
                this.xSpeed = 0;
                this.ySpeed = this.speed;
                break;
        }

        this.born = 0; // Time since new bullet spawned*/
    },

	// Caractéristiques projectile (dépend inputs pour directions)
    update: function (time, delta)
    {
        this.body.setVelocity(this.xSpeed  , this.ySpeed  );
        this.born += delta;
        if (this.born > 400)
        {
            this.setActive(false);
            this.setVisible(false);
			this.destroy();
        }
    }		
});



/* PRELOAD **************************************************************************************/
function preload(){	
	this.load.image('shuri','assets/shuriken.png');
	this.load.image('background','assets/sol3.png');
	this.load.image('rocc','assets/rocher1.png');
	this.load.image('roc5','assets/rocher5.png');
	this.load.image('roc6','assets/rocher6.png');
	this.load.image('mur5','assets/mur5.png');
	this.load.image('mur6','assets/mur6.png');
	this.load.image('murpg','assets/murpg.png');
	this.load.image('murpg_2','assets/murpg_2.png');
	this.load.image('arbre','assets/arbre.png');
	this.load.image('cactus','assets/cactus.png');
	//this.load.image('lac','assets/lac.png');
	this.load.image('itemshuri','assets/item_shu.png');
	this.load.image('itemvie','assets/item_vie.png');
	this.load.image('itemcle','assets/item_cle.png');
	this.load.spritesheet('perso','assets/explo2.png',{frameWidth: 36, frameHeight: 50});
	this.load.spritesheet('scorpio','assets/scorpion.png',{frameWidth: 46, frameHeight: 50});
	this.load.spritesheet('snake','assets/cobra.png',{frameWidth: 46, frameHeight: 50});
	this.load.image('bloc','assets/bloc.png');
	this.load.image('dalle','assets/dalle.png');
	this.load.image('dalle_2','assets/dalle_2.png');
	this.load.image('porte6','assets/porte6.png');
	this.load.image('porte5','assets/porte5.png');
	this.load.image('pilier','assets/pilier.png');
	this.load.image('fleche','assets/fleche.png');
	
}


/* CREATE ***************************************************************************************/
function create(){
	
	// Creation variables
	var back = this.add.image(-200,-200,'background').setOrigin(0);
	this.cameras.main.setBounds(0, 0, 1350 * 2, 1150 * 2);
    this.physics.world.setBounds(0, 0, 1350 * 2, 1150 * 2);
	
	var ammotext = this.add.text(100,100, 'Munitions: 10', { font: "18px Arial", fill: "#0000ff", align: "left" });
	var livestext = this.add.text(100,120, 'Vies: 3', { font: "18px Arial", fill: "#0000ff", align: "left" });
	var instruction = this.add.text(300,100, 'Haut/Bas/Gauche/Droite pour se deplacer', { font: "15px Arial", fill: "#090909", align: "center" });
	var instruction = this.add.text(300,120, 'Espace pour tirer', { font: "15px Arial", fill: "#090909", align: "center" });
	
	// DECORS*********************************************************************************************
	// EXTERIEUR
	
	
	
	itemshuri = this.physics.add.group();
	itemvie = this.physics.add.group();
	itemcle = this.physics.add.group();
	
	
	fleches1 = this.physics.add.staticGroup();
	fleches1 = this.physics.add.sprite(1915,1750,'fleche');
	fleches1.setVelocity(0,700);
	fleches1.setBounce(1);
	fleches2 = this.physics.add.staticGroup();
	fleches2 = this.physics.add.sprite(1980,1550,'fleche');
	fleches2.setVelocity(0,700);
	fleches2.setBounce(1);
	fleches3 = this.physics.add.staticGroup();
	fleches3 = this.physics.add.sprite(2045,1850,'fleche');
	fleches3.setVelocity(0,700);
	fleches3.setBounce(1);
	fleches4 = this.physics.add.staticGroup();
	fleches4 = this.physics.add.sprite(2110,1650,'fleche');
	fleches4.setVelocity(0,700);
	fleches4.setBounce(1);
	
	
	bloc = this.physics.add.group();
	bloc.create(1100,260,'bloc');
	//bloc.setBounce(1);
	//bloc.setCollideWorldBounds(true);
	
	dalle = this.physics.add.staticGroup();
	dalle.create(215,2190,'dalle');
	dalle_2 = this.physics.add.staticGroup();
	
	murs = this.physics.add.staticGroup();
	murs.create(1340,150,'mur6');
	murs.create(1340,440,'mur6');
	murs.create(1340,730,'mur6');
	murs.create(1340,1020,'mur6');
	murs.create(1340,1310,'mur6');
	murs.create(1340,1600,'mur6');
	murs.create(1340,2020,'mur6');
	
	rochers = this.physics.add.staticGroup();
	
	//rochers.create(150,340,'rocc');
	//rochers.create(90,340,'rocc');
	rochers.create(150,270,'roc5');
	rochers.create(1280,270,'rocc');
	rochers.create(1100,200,'rocc');
	
	rochers.create(450,30,'roc5');
	rochers.create(750,30,'roc5');
	rochers.create(1050,30,'roc5');
	rochers.create(1220,30,'rocc');
	rochers.create(1280,30,'rocc');
	
	rochers.create(30,90,'roc6');
	rochers.create(30,450,'roc6');
	rochers.create(30,750,'roc6');
	rochers.create(30,1050,'roc6');
	rochers.create(30,1350,'roc6');
	rochers.create(30,1650,'roc6');
	rochers.create(30,1950,'roc6');
	rochers.create(140,2250,'roc6');
	rochers.create(80,2130,'rocc');
	rochers.create(20,2130,'rocc');
	
	rochers.create(1340,2200,'rocc');
	rochers.create(1220,2270,'roc5');
	rochers.create(920,2270,'roc5');
	rochers.create(620,2270,'roc5');
	rochers.create(320,2270,'roc5');
	
	arbre = this.physics.add.staticGroup();
	arbre.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'arbre');
	arbre.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'arbre');
	arbre.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'arbre');
	arbre.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'arbre');
	arbre.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'arbre');
	arbre.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'arbre');
	arbre.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'arbre');
	arbre.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'arbre');
	arbre.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'arbre');
	arbre.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'arbre');
	arbre.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'arbre');
	arbre.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'arbre');
	arbre.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'arbre');
	arbre.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'arbre');
	arbre.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'arbre');
	arbre.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'arbre');
	arbre.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'arbre');
	arbre.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'arbre');
	arbre.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'arbre');
	arbre.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'arbre');
	
	
	cactus = this.physics.add.staticGroup();
	cactus.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'cactus');
	cactus.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'cactus');
	cactus.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'cactus');
	cactus.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'cactus');
	cactus.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'cactus');
	cactus.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'cactus');
	cactus.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'cactus');
	cactus.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'cactus');
	cactus.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'cactus');
	cactus.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'cactus');
	cactus.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'cactus');
	cactus.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'cactus');
	cactus.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'cactus');
	cactus.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'cactus');
	cactus.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'cactus');
	cactus.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'cactus');
	cactus.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'cactus');
	cactus.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'cactus');
	cactus.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'cactus');
	cactus.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100),'cactus');
	
	piliers = this.physics.add.staticGroup();
	
	// INTERIEUR--------1ere salle
	
	
	piliers.create(1260,1720,'pilier');
	piliers.create(1260,1900,'pilier');
	piliers.create(1410,1620,'pilier');
	piliers.create(1410,1960,'pilier');
	piliers.create(2520,1620,'pilier');
	piliers.create(2520,1960,'pilier');
	
	
	
	murs.create(1460,2030,'mur5');
	murs.create(1750,2030,'mur5');
	murs.create(2040,2030,'murpg');
	murs.create(2480,2030,'mur5');
	murs.create(1460,1550,'mur5');
	murs.create(1750,1550,'mur5');
	murs.create(2040,1550,'murpg_2');
	murs.create(2480,1550,'mur5');
	
	
	murs.create(2480,2270,'mur5');
	murs.create(2280,2270,'mur5');
	murs.create(2160,2150,'mur6');
	
	murs.create(2600,1670,'mur6');
	murs.create(2600,1960,'mur6');
	murs.create(2600,2250,'mur6');
	
	murs.create(2360,1430,'mur6');
	murs.create(2160,1430,'mur6');
	
	
	/////AVATAR
    player = this.physics.add.sprite(200,200,'perso');
    playerShuri = this.physics.add.group({ classType: Shuriken, runChildUpdate: true });
	player.setCollideWorldBounds(true);
	this.physics.add.collider(player, rochers);
	this.physics.add.collider(player, murs);
	this.physics.add.collider(player, arbre);
	this.physics.add.collider(player, cactus);
	this.physics.add.collider(player, bloc);
	this.physics.add.collider(player, piliers);
	
	
	
	this.physics.add.collider(rochers, bloc);
	this.physics.add.collider(arbre, bloc);
	this.physics.add.collider(cactus, bloc);
	this.physics.add.collider(murs, bloc);
	this.physics.add.collider(piliers, bloc);
	
	//this.physics.add.collider(scorpio, bloc);
	//this.physics.add.collider(scorpio2, bloc);
	//this.physics.add.collider(snake, bloc);
	//this.physics.add.collider(snake2, bloc);
	
	// Camera
	cursors = this.input.keyboard.createCursorKeys(); 
	this.cameras.main.startFollow(player,true,1,1,0,0);
	
	// Animation_____TO DO_____bug animations pour 3 directions
	this.anims.create({
		key:'left',
		frames: this.anims.generateFrameNumbers('perso', {start: 0, end: 2}),
		frameRate: 10,
		repeat: -1
	});
	
	this.anims.create({
		key:'right',
		frames: this.anims.generateFrameNumbers('perso', {start: 0, end: 2}),
		frameRate: 10,
		repeat: -1
	});
	
	this.anims.create({
		key:'up',
		frames: this.anims.generateFrameNumbers('perso', {start:0, end: 2}),
		frameRate: 10,
		repeat: -1
	});
	
	this.anims.create({
		key:'down',
		frames: this.anims.generateFrameNumbers('perso', {start: 0, end: 2}),
		frameRate: 10,
		repeat: -1
	});
	
	this.anims.create({
		key:'idle',
		frames: [{key: 'perso', frame:0}],
		frameRate: 20
	});
	
	
	
	
	////PORTES------------
	
	
	portes = this.physics.add.group();
	portes = this.physics.add.sprite(1340,1810,'porte6');
	portes.setImmovable();
	
	portes2 = this.physics.add.group();
	portes2 = this.physics.add.sprite(2260,1550,'porte5');
	portes2.setImmovable();
	
	this.physics.add.collider(player, portes);
	this.physics.add.collider(portes, bloc);
	this.physics.add.collider(player, portes2);
	this.physics.add.collider(portes2, bloc);
	
	
	
	
	
	
	// Scorpio
	
	scorpio = this.physics.add.group();
	scorpio = this.physics.add.sprite(620,2150,'scorpio');
	scorpio.setVelocity(Phaser.Math.Between(-300, 300), -350);
	//scorpio.setVelocity(0,0);
	scorpio.setBounce(1);
	this.anims.create({
		//key:'left',
		frames: this.anims.generateFrameNumbers('scorpio', {start: 0, end: 2}),
		frameRate: 10,
		repeat: -1
	});

    this.physics.add.collider(player,scorpio, hitplayer, null, this);	
    this.physics.add.overlap(playerShuri,scorpio, hitscorpio);	
	scorpio.setCollideWorldBounds(true);
	this.physics.add.collider(rochers,scorpio);
	this.physics.add.collider(arbre,scorpio);
	this.physics.add.collider(cactus,scorpio);
	this.physics.add.collider(murs,scorpio);
	this.physics.add.collider(portes,scorpio);
	this.physics.add.collider(piliers,scorpio);
	
	// Scorpio2
	
	scorpio2 = this.physics.add.group();
	scorpio2 = this.physics.add.sprite(920,2150,'scorpio');
	scorpio2.setVelocity(Phaser.Math.Between(-300, 300), -350);
	//scorpio2.setVelocity(0,0);
	scorpio2.setBounce(1);
	this.anims.create({
		//key:'left',
		frames: this.anims.generateFrameNumbers('scorpio', {start: 0, end: 2}),
		frameRate: 10,
		repeat: -1
	});

    this.physics.add.collider(player,scorpio2, hitplayer, null, this);	
    this.physics.add.overlap(playerShuri,scorpio2, hitscorpio2);	
	scorpio2.setCollideWorldBounds(true);
	this.physics.add.collider(rochers,scorpio2);
	this.physics.add.collider(arbre,scorpio2);
	this.physics.add.collider(cactus,scorpio2);
	this.physics.add.collider(murs,scorpio2);
	this.physics.add.collider(portes,scorpio2);
	this.physics.add.collider(piliers,scorpio2);
	
	// Snake
	
	snake = this.physics.add.group();
	snake = this.physics.add.sprite(320,2150,'snake');
	snake.setVelocity(Phaser.Math.Between(-300, 300), -350);
	//snake.setVelocity(0,0);
	snake.setBounce(1);
	this.anims.create({
		//key:'left',
		frames: this.anims.generateFrameNumbers('scorpio', {start: 0, end: 2}),
		frameRate: 10,
		repeat: -1
	});

    this.physics.add.collider(player,snake, hitplayer, null, this);	
    this.physics.add.overlap(playerShuri,snake, hitsnake);	
	snake.setCollideWorldBounds(true);
	this.physics.add.collider(rochers,snake);
	this.physics.add.collider(arbre,snake);
	this.physics.add.collider(cactus,snake);
	this.physics.add.collider(murs,snake);
	this.physics.add.collider(portes,snake);
	this.physics.add.collider(piliers,snake);
	
	
	// Snake2
	
	snake2 = this.physics.add.group();
	snake2 = this.physics.add.sprite(1220,2150,'snake');
	snake2.setVelocity(Phaser.Math.Between(-300, 300), -350);
	//snake2.setVelocity(0,0);
	snake2.setBounce(1);
	this.anims.create({
		//key:'left',
		frames: this.anims.generateFrameNumbers('scorpio', {start: 0, end: 2}),
		frameRate: 10,
		repeat: -1
	});

    this.physics.add.collider(player,snake2, hitplayer, null, this);	
    this.physics.add.overlap(playerShuri,snake2, hitsnake2);	
	snake.setCollideWorldBounds(true);
	this.physics.add.collider(rochers,snake2);
	this.physics.add.collider(arbre,snake2);
	this.physics.add.collider(cactus,snake2);
	this.physics.add.collider(murs,snake2);
	this.physics.add.collider(portes,snake2);
	this.physics.add.collider(piliers,snake2);
	
	
	///colliders projectiles
	this.physics.add.collider(rochers,playerShuri);
	this.physics.add.collider(arbre,playerShuri);
	this.physics.add.collider(cactus,playerShuri);
	this.physics.add.collider(murs,playerShuri);
	this.physics.add.collider(portes,playerShuri);
	this.physics.add.collider(piliers,playerShuri);
	
	
	this.physics.add.collider(fleches1,murs);
	this.physics.add.collider(fleches2,murs);
	this.physics.add.collider(fleches3,murs);
	this.physics.add.collider(fleches4,murs);
	this.physics.add.collider(player,fleches1,hitfleche, null, this);
	this.physics.add.collider(player,fleches2,hitfleche, null, this);
	this.physics.add.collider(player,fleches3,hitfleche, null, this);
	this.physics.add.collider(player,fleches4,hitfleche, null, this);
	
	
	
	////ITEMS 
	
	this.physics.add.overlap(dalle,bloc,opendoor);
	
	itemshuri.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100) ,'itemshuri'); 
	itemshuri.create(Phaser.Math.Between(100,1250),Phaser.Math.Between(100,2100) ,'itemshuri');  
	itemvie.create(2540,2100,'itemvie');  
	itemcle.create(2540,2200,'itemcle'); 
	
	
	player.health = 3;
   
	this.physics.add.overlap(player,itemshuri,collectshuri);
	this.physics.add.overlap(player,itemvie,collectvie);
	this.physics.add.overlap(player,itemcle,collectcle);

	
	
    ////CONTROLES*******************************************************************************************
    var keyObj = this.input.keyboard.addKey('UP');
    keyObj.on('down', function(event) {
        player.setVelocity(0, -playerSpeed);
        player.anims.play('up');
        player.heading = UP;
		
		
    });
    keyObj.on('up', function(event) {        
       if(cursors.down.isDown) {
            player.setVelocity(0, playerSpeed);
            player.anims.play('down');
            player.heading = DOWN;
        }
       else if (cursors.left.isDown) {
            player.setVelocity(-playerSpeed, 0);
            player.anims.play('left');
            player.heading = LEFT;
        }
       else if (cursors.right.isDown) {
            player.setVelocity(playerSpeed, 0);
            player.anims.play('right');
            player.heading = RIGHT;
        }
        else {
            player.setVelocity(0);
            player.anims.play('idle');
            player.heading = UP;
        }        
    });

    keyObj = this.input.keyboard.addKey('DOWN');
    keyObj.on('down', function(event) {
        player.setVelocity(0, playerSpeed);
        player.anims.play('down');
        player.heading = DOWN;
    });
    keyObj.on('up', function(event) {
        if(cursors.up.isDown) {
            player.setVelocity(0, -playerSpeed);
            player.anims.play('up');
            player.heading = UP;
        }
        else if (cursors.left.isDown) {
            player.setVelocity(-playerSpeed, 0);
            player.anims.play('left');
            player.heading = LEFT;
        }
        else if (cursors.right.isDown) {
            player.setVelocity(playerSpeed, 0);
            player.anims.play('right');
            player.heading = RIGHT;
        }
        else {
            player.setVelocity(0);
            player.anims.play('idle');
            player.heading = DOWN;
        }    
    });

    keyObj = this.input.keyboard.addKey('LEFT');
    keyObj.on('down', function(event) {
        player.setVelocity(-playerSpeed, 0);
        player.anims.play('left');
        player.heading = LEFT;
    });
    keyObj.on('up', function(event) {
        if(cursors.up.isDown) {
            player.setVelocity(0, -playerSpeed);
            player.anims.play('up');
            player.heading = UP;
        }
        else if (cursors.down.isDown) {
            player.setVelocity(0, playerSpeed);
            player.anims.play('down');
            player.heading = DOWN;
        }
        else if (cursors.right.isDown) {
            player.setVelocity(playerSpeed, 0);
            player.anims.play('right');
            player.heading = RIGHT;
        }
        else {
            player.setVelocity(0);
            player.anims.play('idle');
            player.heading = LEFT;
        }    
    });

    keyObj = this.input.keyboard.addKey('RIGHT');
    keyObj.on('down', function(event) {
        player.setVelocity(playerSpeed, 0);
        player.anims.play('right');
        player.heading = RIGHT;
    });
    keyObj.on('up', function(event) {
        if(cursors.up.isDown) {
            player.setVelocity(0, -playerSpeed);
            player.anims.play('up');
            player.heading = UP;
        }
        else if (cursors.down.isDown) {
            player.setVelocity(0, playerSpeed);
            player.anims.play('down');
            player.heading = DOWN;
        }
        else if (cursors.left.isDown) {
            player.setVelocity(-playerSpeed, 0);
            player.anims.play('left');
            player.heading = LEFT;
        }
        else {
            player.setVelocity(0);
            player.anims.play('idle');
            player.heading = RIGHT;
        }    
    });

    keyObj = this.input.keyboard.addKey('SPACE');
    keyObj.on('down', function(event) {
        var shuri = playerShuri.get().setActive(true).setVisible(true);
		nbshuri = nbshuri -1;
        if ((shuri)&& nbshuri >= 0){
            shuri.fire(player);
			ammotext.setText('munitions: '+nbshuri);
			
        }
    });
}
	

/* UPDATE ***************************************************************************************/

//Tirs du joueurs
function update (time, delta)
{	
    if(direction != player.heading) {
        direction = player.heading;
    }
	
	if (nbshuri <= 0)
		{
			//player.setTint(0xff0000);
							
			}
}

//Disparition des ennemis
function hitscorpio(shuri, scorpio){
	
	scorpio.destroy();
	shuri.destroy();
      
}

function hitscorpio2(shuri, scorpio2){
	
	scorpio2.destroy();
	shuri.destroy();
       
}

function hitsnake(shuri, snake){
	
	snake.destroy();
	shuri.destroy();
    itemshuri.create(snake.x  , snake.y  ,'itemshuri');    
}
function hitsnake2(shuri, snake2){
	
	snake2.destroy();
	shuri.destroy();
    itemshuri.create(snake2.x  , snake2.y  ,'itemvie');    
}



//Joueur blesse par ennemi
function hitplayer(player, scorpio){
	
	//player.setTint(0xff0000);
	player.anims.play('idle');
	player.health = player.health - 1;
      
		if (player.health <= 0)
        {
           this.physics.pause();
		   player.setTint(0xff0000);
		   gameOver=true;
        }
}

//Joueur blesse par piège
function hitfleche(player, fleches1){
	
	//player.setTint(0xff0000);
	player.anims.play('idle');
	player.health = player.health - 1;
      
		if (player.health <= 0)
        {
           this.physics.pause();
		   player.setTint(0xff0000);
		   gameOver=true;
        }
}


//Récolte items
function collectshuri(player, itemshuri){
	
	nbshuri = nbshuri + 1;
	itemshuri.disableBody(true,true);
	//ammotext.setText('munitions: '+nbshuri);

	
	
}

function collectvie(player, itemvie){
	
	player.health = player.health + 1;
	itemvie.disableBody(true,true);
	//livestexttext.setText('vie: '+player.health);

}



function collectcle(player, itemcle){
	
	itemcle.disableBody(true,true);
	portes2.destroy();
}



//Déclencheur porte
function opendoor(dalle, bloc){
	
	portes.destroy();
	//dalle.disableBody(true,true);
	dalle.destroy();
	dalle_2.create(215,2190,'dalle_2');
	
}

